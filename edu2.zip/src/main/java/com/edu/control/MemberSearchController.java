package com.edu.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.edu.common.Controller;
import com.edu.dao.MemberDAO;
import com.edu.model.MemberVO;

public class MemberSearchController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//memberSearch.jsp id 검색 결과 memberResult/memberSearchOutput.jsp
		String id = req.getParameter("id");
		
		MemberDAO dao = new MemberDAO();
		MemberVO vo = dao.getMemeber(id);
		
		req.setAttribute("member", vo);//요청정보member속성 = vo
		
		String job = req.getParameter("job");
		String path= "";
		
		if(job.equals("delete")) {
			path = "memberView/memberDelete.jsp";
		}else if(job.equals("update")){
			path = "memberView/memberUpdate.jsp";
		
		}else {
			path="memberResult/memberSearchOutput.jsp";
		}
		
		req.getRequestDispatcher(path).forward(req, resp);
	}

}
